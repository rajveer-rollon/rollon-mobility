import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { LanguageProvider } from "@/contexts/LanguageContext";
import Home from "@/pages/Home";
import PartnerDashboard from "@/pages/PartnerDashboard";
import AdminDashboard from "@/pages/AdminDashboard";
import PartnerOnboarding from "@/pages/PartnerOnboarding";
import Accessibility from "@/pages/Accessibility";
import RSA from "@/pages/RSA";
import PartnerLogin from "@/pages/PartnerLogin";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/partner/login" component={PartnerLogin} />
      <Route path="/partner/dashboard" component={PartnerDashboard} />
      <Route path="/partner/onboarding" component={PartnerOnboarding} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/accessibility" component={Accessibility} />
      <Route path="/rsa" component={RSA} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
