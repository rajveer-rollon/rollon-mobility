import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Type, Eye, Volume2, Smartphone } from "lucide-react";

interface AccessibilitySettingsProps {
  largeText: boolean;
  highContrast: boolean;
  voiceAssist: boolean;
  hapticFeedback: boolean;
  onToggleLargeText: (enabled: boolean) => void;
  onToggleHighContrast: (enabled: boolean) => void;
  onToggleVoiceAssist: (enabled: boolean) => void;
  onToggleHapticFeedback: (enabled: boolean) => void;
  translations: {
    accessibility: string;
    accessibilityDescription: string;
    largeText: string;
    largeTextDescription: string;
    highContrast: string;
    highContrastDescription: string;
    voiceAssist: string;
    voiceAssistDescription: string;
    hapticFeedback: string;
    hapticFeedbackDescription: string;
  };
}

export default function AccessibilitySettings({
  largeText,
  highContrast,
  voiceAssist,
  hapticFeedback,
  onToggleLargeText,
  onToggleHighContrast,
  onToggleVoiceAssist,
  onToggleHapticFeedback,
  translations,
}: AccessibilitySettingsProps) {
  const settings = [
    {
      id: 'large-text',
      icon: Type,
      title: translations.largeText,
      description: translations.largeTextDescription,
      checked: largeText,
      onChange: onToggleLargeText,
    },
    {
      id: 'high-contrast',
      icon: Eye,
      title: translations.highContrast,
      description: translations.highContrastDescription,
      checked: highContrast,
      onChange: onToggleHighContrast,
    },
    {
      id: 'voice-assist',
      icon: Volume2,
      title: translations.voiceAssist,
      description: translations.voiceAssistDescription,
      checked: voiceAssist,
      onChange: onToggleVoiceAssist,
    },
    {
      id: 'haptic-feedback',
      icon: Smartphone,
      title: translations.hapticFeedback,
      description: translations.hapticFeedbackDescription,
      checked: hapticFeedback,
      onChange: onToggleHapticFeedback,
    },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>{translations.accessibility}</CardTitle>
        <CardDescription>{translations.accessibilityDescription}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {settings.map((setting, index) => {
          const Icon = setting.icon;
          return (
            <div key={setting.id}>
              {index > 0 && <Separator className="my-4" />}
              <div className="flex items-start justify-between gap-4">
                <div className="flex gap-3 flex-1">
                  <Icon className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                  <div className="space-y-1 flex-1">
                    <Label htmlFor={setting.id} className="text-base font-medium cursor-pointer">
                      {setting.title}
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      {setting.description}
                    </p>
                  </div>
                </div>
                <Switch
                  id={setting.id}
                  checked={setting.checked}
                  onCheckedChange={setting.onChange}
                  data-testid={`switch-${setting.id}`}
                />
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
