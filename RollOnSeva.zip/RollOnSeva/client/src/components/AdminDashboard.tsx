import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Users,
  Package,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
  FileText,
  Download,
} from "lucide-react";

interface KYCReview {
  id: string;
  businessName: string;
  ownerName: string;
  category: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedDate: string;
}

interface AdminDashboardProps {
  totalPartners: number;
  pendingKYC: number;
  activeOrders: number;
  totalRevenue: number;
  kycReviews: KYCReview[];
  onApproveKYC: (id: string) => void;
  onRejectKYC: (id: string) => void;
  translations: {
    adminDashboard: string;
    totalPartners: string;
    pendingKYC: string;
    activeOrders: string;
    totalRevenue: string;
    kycReview: string;
    orders: string;
    payouts: string;
    support: string;
    businessName: string;
    owner: string;
    category: string;
    status: string;
    submitted: string;
    approve: string;
    reject: string;
    viewDocuments: string;
    exportCSV: string;
    pending: string;
    approved: string;
    rejected: string;
  };
}

export default function AdminDashboard({
  totalPartners,
  pendingKYC,
  activeOrders,
  totalRevenue,
  kycReviews,
  onApproveKYC,
  onRejectKYC,
  translations,
}: AdminDashboardProps) {
  const getStatusBadge = (status: KYCReview['status']) => {
    const variants = {
      'pending': { variant: 'secondary' as const, icon: Clock, label: translations.pending, className: '' },
      'approved': { variant: 'default' as const, icon: CheckCircle, label: translations.approved, className: 'bg-secondary' },
      'rejected': { variant: 'destructive' as const, icon: AlertCircle, label: translations.rejected, className: '' },
    };
    
    const config = variants[status];
    const Icon = config.icon;
    
    return (
      <Badge variant={config.variant} className={config.className || undefined}>
        <Icon className="h-3 w-3 mr-1" />
        {config.label}
      </Badge>
    );
  };

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-bold">{translations.adminDashboard}</h1>
        <p className="text-muted-foreground">RollOn Mobility Admin Portal</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {translations.totalPartners}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              <span className="text-2xl font-bold">{totalPartners}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {translations.pendingKYC}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-accent" />
              <span className="text-2xl font-bold">{pendingKYC}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {translations.activeOrders}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Package className="h-5 w-5 text-secondary" />
              <span className="text-2xl font-bold">{activeOrders}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {translations.totalRevenue}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <span className="text-2xl font-bold">₹{totalRevenue.toLocaleString()}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="kyc" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="kyc" data-testid="tab-kyc">
            {translations.kycReview}
          </TabsTrigger>
          <TabsTrigger value="orders" data-testid="tab-orders">
            {translations.orders}
          </TabsTrigger>
          <TabsTrigger value="payouts" data-testid="tab-payouts">
            {translations.payouts}
          </TabsTrigger>
          <TabsTrigger value="support" data-testid="tab-support">
            {translations.support}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="kyc" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">{translations.kycReview}</h2>
            <Button variant="outline" size="sm" data-testid="button-export-csv">
              <Download className="h-4 w-4 mr-2" />
              {translations.exportCSV}
            </Button>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="divide-y">
                {kycReviews.map((review) => (
                  <div
                    key={review.id}
                    className="p-4 hover-elevate"
                    data-testid={`kyc-review-${review.id}`}
                  >
                    <div className="flex items-center justify-between gap-4 flex-wrap">
                      <div className="flex-1 min-w-[200px]">
                        <div className="font-medium">{review.businessName}</div>
                        <div className="text-sm text-muted-foreground">{review.ownerName}</div>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="outline">{review.category}</Badge>
                          <span className="text-xs text-muted-foreground">
                            {review.submittedDate}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        {getStatusBadge(review.status)}
                        {review.status === 'pending' && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              data-testid={`button-view-docs-${review.id}`}
                            >
                              <FileText className="h-4 w-4 mr-1" />
                              {translations.viewDocuments}
                            </Button>
                            <Button
                              variant="default"
                              size="sm"
                              onClick={() => onApproveKYC(review.id)}
                              data-testid={`button-approve-${review.id}`}
                              className="bg-secondary hover:bg-secondary/90"
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              {translations.approve}
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => onRejectKYC(review.id)}
                              data-testid={`button-reject-${review.id}`}
                            >
                              <AlertCircle className="h-4 w-4 mr-1" />
                              {translations.reject}
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orders">
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              Orders management coming soon
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payouts">
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              Payouts management coming soon
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="support">
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              Support tickets coming soon
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
