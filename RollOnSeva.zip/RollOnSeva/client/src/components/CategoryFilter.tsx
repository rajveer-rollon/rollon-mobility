import { Badge } from "@/components/ui/badge";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import wrenchIcon from "@assets/generated_images/Garage_wrench_icon_1306e441.png";
import tyreIcon from "@assets/generated_images/Tyre_shop_icon_b9a5d501.png";
import evIcon from "@assets/generated_images/EV_charging_icon_78775a0b.png";
import partsIcon from "@assets/generated_images/Auto_parts_icon_35ec038a.png";

export type ServiceCategory = 'all' | 'emergency' | 'tyre' | 'garage' | 'ev' | 'parts';

interface CategoryFilterProps {
  selectedCategory: ServiceCategory;
  onCategoryChange: (category: ServiceCategory) => void;
  translations: {
    all: string;
    emergencyAssistance: string;
    tyreShop: string;
    garage: string;
    evCharging: string;
    autoParts: string;
  };
}

const categories = [
  { id: 'all' as ServiceCategory, labelKey: 'all' as const, icon: null },
  { id: 'emergency' as ServiceCategory, labelKey: 'emergencyAssistance' as const, icon: null },
  { id: 'tyre' as ServiceCategory, labelKey: 'tyreShop' as const, icon: tyreIcon },
  { id: 'garage' as ServiceCategory, labelKey: 'garage' as const, icon: wrenchIcon },
  { id: 'ev' as ServiceCategory, labelKey: 'evCharging' as const, icon: evIcon },
  { id: 'parts' as ServiceCategory, labelKey: 'autoParts' as const, icon: partsIcon },
];

export default function CategoryFilter({ selectedCategory, onCategoryChange, translations }: CategoryFilterProps) {
  return (
    <ScrollArea className="w-full">
      <div className="flex gap-2 p-4">
        {categories.map((cat) => (
          <Badge
            key={cat.id}
            variant={selectedCategory === cat.id ? 'default' : 'secondary'}
            className="cursor-pointer whitespace-nowrap flex items-center gap-1.5 px-3 py-2 hover-elevate"
            onClick={() => onCategoryChange(cat.id)}
            data-testid={`filter-category-${cat.id}`}
          >
            {cat.icon && (
              <img src={cat.icon} alt="" className="h-4 w-4" />
            )}
            <span>{translations[cat.labelKey]}</span>
          </Badge>
        ))}
      </div>
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  );
}
