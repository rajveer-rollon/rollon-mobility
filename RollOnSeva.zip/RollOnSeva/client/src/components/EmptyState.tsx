import { Card, CardContent } from "@/components/ui/card";
import emptyImage from "@assets/generated_images/No_services_found_illustration_9b7e9110.png";

interface EmptyStateProps {
  translations: {
    noServicesFound: string;
    tryDifferentLocation: string;
  };
}

export default function EmptyState({ translations }: EmptyStateProps) {
  return (
    <Card className="mx-4">
      <CardContent className="flex flex-col items-center justify-center py-12 px-6 text-center">
        <img
          src={emptyImage}
          alt="No services found"
          className="w-48 h-48 mb-6 object-contain"
        />
        <h3 className="text-lg font-semibold mb-2">{translations.noServicesFound}</h3>
        <p className="text-sm text-muted-foreground">{translations.tryDifferentLocation}</p>
      </CardContent>
    </Card>
  );
}
