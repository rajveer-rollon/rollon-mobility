import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, BadgeCheck, Shield } from "lucide-react";
import heroImage from "@assets/generated_images/Indian_roadside_assistance_hero_bb69dd00.png";
import TricolourWave from "./TricolourWave";

interface HeroProps {
  onGetStarted: () => void;
  translations: {
    appName: string;
    tagline: string;
    instantHelp: string;
    sosDescription: string;
    trustedPartners: string;
    commissionFree: string;
  };
}

export default function Hero({ onGetStarted, translations }: HeroProps) {
  return (
    <div className="relative h-screen w-full overflow-hidden">
      <div className="absolute top-0 left-0 right-0 z-20">
        <TricolourWave />
      </div>
      
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70" />
      </div>

      <div className="relative h-full flex flex-col items-center justify-center px-6 text-center text-white z-10">
        <Badge variant="outline" className="mb-6 bg-white/10 backdrop-blur-sm border-white/20 text-white">
          <Shield className="h-3 w-3 mr-1" />
          {translations.trustedPartners}
        </Badge>

        <h1 className="text-4xl md:text-6xl font-bold mb-4 max-w-4xl">
          {translations.appName}
        </h1>
        
        <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-2xl">
          {translations.tagline}
        </p>

        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <Button
            size="lg"
            variant="default"
            onClick={onGetStarted}
            className="text-lg px-8"
            data-testid="button-get-started"
          >
            <MapPin className="h-5 w-5 mr-2" />
            {translations.instantHelp}
          </Button>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-6 text-sm">
          <div className="flex items-center gap-2">
            <BadgeCheck className="h-5 w-5 text-primary" />
            <span>10,000+ Verified Partners</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            <span>{translations.commissionFree}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
