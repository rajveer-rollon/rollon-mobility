export default function IndiaMapWatermark() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-[0.03]">
      <svg
        viewBox="0 0 400 600"
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M200,50 L220,70 L240,65 L245,85 L260,90 L270,110 L280,130 L290,150 L295,170 L300,190 L305,210 L308,230 L310,250 L312,270 L310,290 L305,310 L300,330 L290,350 L280,370 L270,390 L260,410 L250,430 L240,450 L230,470 L220,490 L210,510 L200,520 L190,510 L180,490 L170,470 L160,450 L150,430 L140,410 L130,390 L120,370 L110,350 L100,330 L95,310 L90,290 L88,270 L90,250 L92,230 L95,210 L100,190 L105,170 L110,150 L120,130 L130,110 L140,90 L155,85 L160,65 L180,70 Z"
          fill="currentColor"
          className="text-foreground"
        />
      </svg>
    </div>
  );
}
