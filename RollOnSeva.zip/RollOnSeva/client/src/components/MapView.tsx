import { Card } from "@/components/ui/card";
import { MapPin, Navigation2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface MapViewProps {
  userLocation?: { lat: number; lng: number };
  onRequestLocation: () => void;
}

export default function MapView({ userLocation, onRequestLocation }: MapViewProps) {
  return (
    <Card className="w-full h-96 relative overflow-hidden">
      <div className="absolute inset-0 bg-muted flex items-center justify-center">
        <div className="text-center space-y-4 p-6">
          <MapPin className="h-16 w-16 mx-auto text-muted-foreground" />
          <div>
            <h3 className="font-semibold mb-2">Location Access Required</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Allow location access to find nearby services
            </p>
            <Button onClick={onRequestLocation} data-testid="button-request-location">
              <Navigation2 className="h-4 w-4 mr-2" />
              Enable Location
            </Button>
          </div>
        </div>
      </div>
      {userLocation && (
        <div className="absolute top-4 left-4 bg-card px-3 py-2 rounded-md shadow-md text-sm">
          <div className="flex items-center gap-2">
            <Navigation2 className="h-4 w-4 text-primary" />
            <span className="font-medium">Your Location</span>
          </div>
        </div>
      )}
    </Card>
  );
}
