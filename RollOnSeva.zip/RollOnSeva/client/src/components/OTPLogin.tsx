import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Phone } from "lucide-react";

interface OTPLoginProps {
  onLogin: (phone: string, otp: string) => void;
  translations: {
    phoneLogin: string;
    enterPhone: string;
    phoneNumber: string;
    sendOTP: string;
    enterOTP: string;
    otpSent: string;
    verify: string;
    resendOTP: string;
  };
}

export default function OTPLogin({ onLogin, translations }: OTPLoginProps) {
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState<'phone' | 'otp'>('phone');

  const handleSendOTP = () => {
    if (phone.length === 10) {
      setStep('otp');
      console.log('OTP sent to:', phone);
    }
  };

  const handleVerifyOTP = () => {
    if (otp.length === 6) {
      onLogin(phone, otp);
    }
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Phone className="h-5 w-5 text-primary" />
          {translations.phoneLogin}
        </CardTitle>
        <CardDescription>
          {step === 'phone' ? translations.enterPhone : translations.otpSent}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {step === 'phone' ? (
          <>
            <div className="space-y-2">
              <label className="text-sm font-medium">{translations.phoneNumber}</label>
              <Input
                type="tel"
                placeholder="9876543210"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                maxLength={10}
                data-testid="input-phone-number"
              />
            </div>
            <Button
              className="w-full"
              onClick={handleSendOTP}
              disabled={phone.length !== 10}
              data-testid="button-send-otp"
            >
              {translations.sendOTP}
            </Button>
          </>
        ) : (
          <>
            <div className="space-y-2">
              <label className="text-sm font-medium">{translations.enterOTP}</label>
              <div className="flex justify-center">
                <InputOTP
                  maxLength={6}
                  value={otp}
                  onChange={setOtp}
                  data-testid="input-otp"
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>
            </div>
            <Button
              className="w-full"
              onClick={handleVerifyOTP}
              disabled={otp.length !== 6}
              data-testid="button-verify-otp"
            >
              {translations.verify}
            </Button>
            <Button
              variant="ghost"
              className="w-full"
              onClick={() => setStep('phone')}
              data-testid="button-resend-otp"
            >
              {translations.resendOTP}
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
}
