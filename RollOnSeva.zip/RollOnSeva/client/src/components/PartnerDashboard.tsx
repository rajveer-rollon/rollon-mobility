import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { IndianRupee, Package, TrendingUp, Clock, CheckCircle2, XCircle } from "lucide-react";

interface Order {
  id: string;
  customerName: string;
  service: string;
  amount: number;
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
  time: string;
}

interface PartnerDashboardProps {
  partnerName: string;
  isOnline: boolean;
  onToggleOnline: (online: boolean) => void;
  todayEarnings: number;
  totalOrders: number;
  completedOrders: number;
  pendingOrders: number;
  recentOrders: Order[];
  translations: {
    dashboard: string;
    status: string;
    online: string;
    offline: string;
    todayEarnings: string;
    totalOrders: string;
    completed: string;
    pending: string;
    recentOrders: string;
    viewAll: string;
    inventory: string;
    support: string;
  };
}

export default function PartnerDashboard({
  partnerName,
  isOnline,
  onToggleOnline,
  todayEarnings,
  totalOrders,
  completedOrders,
  pendingOrders,
  recentOrders,
  translations,
}: PartnerDashboardProps) {
  const getStatusBadge = (status: Order['status']) => {
    const variants = {
      'pending': { variant: 'secondary' as const, icon: Clock, className: '' },
      'in-progress': { variant: 'default' as const, icon: TrendingUp, className: '' },
      'completed': { variant: 'default' as const, icon: CheckCircle2, className: 'bg-secondary' },
      'cancelled': { variant: 'secondary' as const, icon: XCircle, className: '' },
    };
    
    const config = variants[status];
    const Icon = config.icon;
    
    return (
      <Badge variant={config.variant} className={config.className || undefined}>
        <Icon className="h-3 w-3 mr-1" />
        {status}
      </Badge>
    );
  };

  return (
    <div className="space-y-6 p-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Welcome, {partnerName}</h1>
          <p className="text-sm text-muted-foreground">{translations.dashboard}</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm font-medium">
            {isOnline ? translations.online : translations.offline}
          </span>
          <Switch
            checked={isOnline}
            onCheckedChange={onToggleOnline}
            data-testid="switch-online-status"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {translations.todayEarnings}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <IndianRupee className="h-5 w-5 text-primary" />
              <span className="text-2xl font-bold">₹{todayEarnings.toLocaleString()}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {translations.totalOrders}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Package className="h-5 w-5 text-accent" />
              <span className="text-2xl font-bold">{totalOrders}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {translations.completed}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-secondary" />
              <span className="text-2xl font-bold">{completedOrders}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {translations.pending}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-muted-foreground" />
              <span className="text-2xl font-bold">{pendingOrders}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>{translations.recentOrders}</CardTitle>
            <Button variant="ghost" size="sm" data-testid="button-view-all-orders">
              {translations.viewAll}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentOrders.map((order) => (
              <div
                key={order.id}
                className="flex items-center justify-between p-3 border border-border rounded-lg hover-elevate"
                data-testid={`order-${order.id}`}
              >
                <div className="flex-1">
                  <div className="font-medium">{order.customerName}</div>
                  <div className="text-sm text-muted-foreground">{order.service}</div>
                  <div className="text-xs text-muted-foreground mt-1">{order.time}</div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="font-semibold">₹{order.amount}</div>
                    <div className="mt-1">{getStatusBadge(order.status)}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Button variant="default" size="lg" data-testid="button-inventory">
          <Package className="h-5 w-5 mr-2" />
          {translations.inventory}
        </Button>
        <Button variant="outline" size="lg" data-testid="button-support">
          {translations.support}
        </Button>
      </div>
    </div>
  );
}
