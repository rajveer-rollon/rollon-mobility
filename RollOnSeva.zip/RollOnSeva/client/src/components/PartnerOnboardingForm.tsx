import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Upload } from "lucide-react";

const formSchema = z.object({
  businessName: z.string().min(2, "Business name is required"),
  ownerName: z.string().min(2, "Owner name is required"),
  phone: z.string().regex(/^[0-9]{10}$/, "Enter valid 10-digit phone number"),
  address: z.string().min(10, "Address is required"),
  city: z.string().min(2, "City is required"),
  category: z.string().min(1, "Category is required"),
  operatingHours: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface PartnerOnboardingFormProps {
  onSubmit: (data: FormValues & { kycDocument?: File }) => void;
  translations: {
    becomePartner: string;
    registerBusiness: string;
    businessName: string;
    ownerName: string;
    phoneNumber: string;
    address: string;
    city: string;
    category: string;
    operatingHours: string;
    submit: string;
    kycUpload: string;
    garage: string;
    tyreShop: string;
    evCharging: string;
    autoParts: string;
    emergencyAssistance: string;
  };
}

export default function PartnerOnboardingForm({ onSubmit, translations }: PartnerOnboardingFormProps) {
  const [kycFile, setKycFile] = useState<File | undefined>();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      businessName: "",
      ownerName: "",
      phone: "",
      address: "",
      city: "",
      category: "",
      operatingHours: "",
    },
  });

  const handleSubmit = (data: FormValues) => {
    onSubmit({ ...data, kycDocument: kycFile });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl">{translations.becomePartner}</CardTitle>
        <CardDescription>{translations.registerBusiness}</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="businessName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{translations.businessName}</FormLabel>
                  <FormControl>
                    <Input {...field} data-testid="input-business-name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="ownerName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{translations.ownerName}</FormLabel>
                  <FormControl>
                    <Input {...field} data-testid="input-owner-name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{translations.phoneNumber}</FormLabel>
                  <FormControl>
                    <Input {...field} type="tel" data-testid="input-phone" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{translations.category}</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-category">
                        <SelectValue placeholder={translations.category} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="garage">{translations.garage}</SelectItem>
                      <SelectItem value="tyre">{translations.tyreShop}</SelectItem>
                      <SelectItem value="ev">{translations.evCharging}</SelectItem>
                      <SelectItem value="parts">{translations.autoParts}</SelectItem>
                      <SelectItem value="emergency">{translations.emergencyAssistance}</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{translations.address}</FormLabel>
                  <FormControl>
                    <Textarea {...field} data-testid="input-address" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{translations.city}</FormLabel>
                  <FormControl>
                    <Input {...field} data-testid="input-city" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="operatingHours"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{translations.operatingHours} (Optional)</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="9:00 AM - 8:00 PM" data-testid="input-hours" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-2">
              <FormLabel>{translations.kycUpload}</FormLabel>
              <div className="flex items-center gap-2">
                <Input
                  type="file"
                  accept="image/*,.pdf"
                  onChange={(e) => setKycFile(e.target.files?.[0])}
                  className="hidden"
                  id="kyc-upload"
                  data-testid="input-kyc-file"
                />
                <label
                  htmlFor="kyc-upload"
                  className="flex items-center justify-center gap-2 flex-1 border border-input rounded-md px-4 py-2 cursor-pointer hover-elevate"
                >
                  <Upload className="h-4 w-4" />
                  <span className="text-sm">{kycFile ? kycFile.name : 'Choose file'}</span>
                </label>
              </div>
            </div>

            <Button type="submit" className="w-full" data-testid="button-submit-partner">
              {translations.submit}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
