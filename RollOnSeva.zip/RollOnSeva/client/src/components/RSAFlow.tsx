import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Phone, Navigation, Clock, User, Wrench } from "lucide-react";
import { Progress } from "@/components/ui/progress";

type RSAStatus = 'requesting' | 'assigned' | 'enroute' | 'arrived' | 'completed';

interface RSAProvider {
  name: string;
  phone: string;
  vehicle: string;
  eta: string;
  distance: string;
}

interface RSAFlowProps {
  status: RSAStatus;
  provider?: RSAProvider;
  requestTime: string;
  location: string;
  issue: string;
  onCall?: () => void;
  onNavigate?: () => void;
  onCancel?: () => void;
  translations: {
    rsaRequest: string;
    requesting: string;
    assigned: string;
    enroute: string;
    arrived: string;
    completed: string;
    provider: string;
    eta: string;
    distance: string;
    issue: string;
    location: string;
    requestedAt: string;
    call: string;
    navigate: string;
    cancel: string;
    findingNearby: string;
    onTheWay: string;
    providerArrived: string;
    serviceCompleted: string;
  };
}

export default function RSAFlow({
  status,
  provider,
  requestTime,
  location,
  issue,
  onCall,
  onNavigate,
  onCancel,
  translations,
}: RSAFlowProps) {
  const statusConfig = {
    requesting: { progress: 20, label: translations.requesting, message: translations.findingNearby },
    assigned: { progress: 40, label: translations.assigned, message: translations.provider + ' assigned' },
    enroute: { progress: 60, label: translations.enroute, message: translations.onTheWay },
    arrived: { progress: 80, label: translations.arrived, message: translations.providerArrived },
    completed: { progress: 100, label: translations.completed, message: translations.serviceCompleted },
  };

  const config = statusConfig[status];

  return (
    <div className="space-y-4 p-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Wrench className="h-5 w-5 text-destructive" />
              {translations.rsaRequest}
            </CardTitle>
            <Badge variant={status === 'completed' ? 'default' : 'secondary'} className={status === 'completed' ? 'bg-secondary' : ''}>
              {config.label}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Progress</span>
              <span className="font-medium">{config.progress}%</span>
            </div>
            <Progress value={config.progress} className="h-2" />
            <p className="text-sm text-muted-foreground">{config.message}</p>
          </div>

          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div className="flex-1">
                <div className="text-sm font-medium">{translations.location}</div>
                <div className="text-sm text-muted-foreground">{location}</div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Wrench className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div className="flex-1">
                <div className="text-sm font-medium">{translations.issue}</div>
                <div className="text-sm text-muted-foreground">{issue}</div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Clock className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div className="flex-1">
                <div className="text-sm font-medium">{translations.requestedAt}</div>
                <div className="text-sm text-muted-foreground">{requestTime}</div>
              </div>
            </div>
          </div>

          {provider && (status === 'assigned' || status === 'enroute' || status === 'arrived') && (
            <Card className="bg-muted/50">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <User className="h-5 w-5 text-primary" />
                  <div className="flex-1">
                    <div className="font-medium">{provider.name}</div>
                    <div className="text-sm text-muted-foreground">{provider.vehicle}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground">{translations.eta}</div>
                    <div className="font-medium">{provider.eta}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">{translations.distance}</div>
                    <div className="font-medium">{provider.distance}</div>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button
                    variant="default"
                    size="sm"
                    className="flex-1"
                    onClick={onCall}
                    data-testid="button-call-provider"
                  >
                    <Phone className="h-4 w-4 mr-1" />
                    {translations.call}
                  </Button>
                  <Button
                    variant="secondary"
                    size="sm"
                    className="flex-1"
                    onClick={onNavigate}
                    data-testid="button-navigate-provider"
                  >
                    <Navigation className="h-4 w-4 mr-1" />
                    {translations.navigate}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {status !== 'completed' && onCancel && (
            <Button
              variant="outline"
              className="w-full"
              onClick={onCancel}
              data-testid="button-cancel-rsa"
            >
              {translations.cancel}
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
