import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface SOSButtonProps {
  onEmergency: () => void;
}

export default function SOSButton({ onEmergency }: SOSButtonProps) {
  const [isPulsing, setIsPulsing] = useState(false);

  const handleClick = () => {
    setIsPulsing(true);
    setTimeout(() => setIsPulsing(false), 1000);
    onEmergency();
  };

  return (
    <Button
      variant="destructive"
      size="lg"
      className={`fixed bottom-24 right-6 h-20 w-20 rounded-full shadow-xl z-50 ${
        isPulsing ? 'animate-ping' : ''
      }`}
      onClick={handleClick}
      data-testid="button-sos-emergency"
    >
      <AlertCircle className="h-10 w-10" />
    </Button>
  );
}
