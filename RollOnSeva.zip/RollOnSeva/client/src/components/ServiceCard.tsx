import { Phone, Navigation, Info, MapPin, Star, BadgeCheck } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface ServiceCardProps {
  id: string;
  businessName: string;
  category: string;
  services: string[];
  distance: number;
  rating?: number;
  phone: string;
  address: string;
  operatingHours?: string;
  isVerified?: boolean;
  isOpen?: boolean;
  onCall: (phone: string) => void;
  onNavigate: (id: string) => void;
  onDetails: (id: string) => void;
}

export default function ServiceCard({
  id,
  businessName,
  category,
  services,
  distance,
  rating,
  phone,
  address,
  operatingHours,
  isVerified = false,
  isOpen = true,
  onCall,
  onNavigate,
  onDetails,
}: ServiceCardProps) {
  return (
    <Card className="hover-elevate" data-testid={`card-service-${id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-semibold text-lg text-foreground" data-testid={`text-business-name-${id}`}>
                {businessName}
              </h3>
              {isVerified && (
                <BadgeCheck className="h-4 w-4 text-primary flex-shrink-0" data-testid={`icon-verified-${id}`} />
              )}
            </div>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <Badge variant="secondary" className="text-xs">
                {category}
              </Badge>
              {rating && (
                <div className="flex items-center gap-1">
                  <Star className="h-3 w-3 fill-primary text-primary" />
                  <span className="text-sm font-medium">{rating}</span>
                </div>
              )}
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <div className="flex items-center gap-1 text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span className="text-sm font-medium">{distance} km</span>
            </div>
            {isOpen ? (
              <Badge variant="default" className="text-xs">Open</Badge>
            ) : (
              <Badge variant="secondary" className="text-xs">Closed</Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap gap-1">
          {services.slice(0, 3).map((service, idx) => (
            <Badge key={idx} variant="outline" className="text-xs">
              {service}
            </Badge>
          ))}
          {services.length > 3 && (
            <Badge variant="outline" className="text-xs">
              +{services.length - 3} more
            </Badge>
          )}
        </div>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4 flex-shrink-0" />
          <span className="line-clamp-1">{address}</span>
        </div>
        
        {operatingHours && (
          <div className="text-sm text-muted-foreground">
            {operatingHours}
          </div>
        )}

        <div className="flex gap-2 pt-2 flex-wrap">
          <Button
            variant="default"
            size="sm"
            className="flex-1 min-w-[80px]"
            onClick={() => onCall(phone)}
            data-testid={`button-call-${id}`}
          >
            <Phone className="h-4 w-4 mr-1" />
            Call
          </Button>
          <Button
            variant="secondary"
            size="sm"
            className="flex-1 min-w-[80px]"
            onClick={() => onNavigate(id)}
            data-testid={`button-navigate-${id}`}
          >
            <Navigation className="h-4 w-4 mr-1" />
            Navigate
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onDetails(id)}
            data-testid={`button-details-${id}`}
          >
            <Info className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
