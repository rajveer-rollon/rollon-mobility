export default function TricolourWave() {
  return (
    <div className="w-full overflow-hidden">
      <svg
        viewBox="0 0 1440 120"
        className="w-full h-auto"
        preserveAspectRatio="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M0,40 C360,80 720,0 1080,40 C1440,80 1440,80 1440,80 L1440,0 L0,0 Z"
          fill="hsl(var(--primary))"
          opacity="0.95"
        />
        <path
          d="M0,60 C360,100 720,20 1080,60 C1440,100 1440,100 1440,100 L1440,30 L0,30 Z"
          fill="hsl(0 0% 100%)"
          opacity="0.9"
        />
        <path
          d="M0,80 C360,120 720,40 1080,80 C1440,120 1440,120 1440,120 L1440,50 L0,50 Z"
          fill="hsl(var(--secondary))"
          opacity="0.95"
        />
      </svg>
    </div>
  );
}
