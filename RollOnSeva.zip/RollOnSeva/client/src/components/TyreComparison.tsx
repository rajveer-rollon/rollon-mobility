import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone } from "lucide-react";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";

interface TyreDeal {
  id: string;
  brand: string;
  model: string;
  size: string;
  price: number;
  availability: boolean;
  shopName: string;
  phone: string;
}

interface TyreComparisonProps {
  deals: TyreDeal[];
  onContact: (phone: string) => void;
  translations: {
    tyreComparison: string;
    brand: string;
    model: string;
    size: string;
    price: string;
    availability: string;
    contactDealer: string;
    available: string;
    outOfStock: string;
  };
}

export default function TyreComparison({ deals, onContact, translations }: TyreComparisonProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{translations.tyreComparison}</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="w-full">
          <div className="flex gap-4 pb-4">
            {deals.map((deal) => (
              <div
                key={deal.id}
                className="min-w-[240px] p-4 border border-border rounded-md space-y-3"
                data-testid={`card-tyre-${deal.id}`}
              >
                <div>
                  <div className="font-semibold text-lg">{deal.brand}</div>
                  <div className="text-sm text-muted-foreground">{deal.model}</div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{translations.size}:</span>
                    <span className="font-medium">{deal.size}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{translations.price}:</span>
                    <span className="font-semibold text-lg">₹{deal.price.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">{translations.availability}:</span>
                    {deal.availability ? (
                      <Badge variant="default" className="text-xs">{translations.available}</Badge>
                    ) : (
                      <Badge variant="secondary" className="text-xs">{translations.outOfStock}</Badge>
                    )}
                  </div>
                </div>

                <div className="pt-2 border-t">
                  <div className="text-sm font-medium mb-2">{deal.shopName}</div>
                  <Button
                    variant="default"
                    size="sm"
                    className="w-full"
                    onClick={() => onContact(deal.phone)}
                    data-testid={`button-contact-${deal.id}`}
                  >
                    <Phone className="h-4 w-4 mr-1" />
                    {translations.contactDealer}
                  </Button>
                </div>
              </div>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
