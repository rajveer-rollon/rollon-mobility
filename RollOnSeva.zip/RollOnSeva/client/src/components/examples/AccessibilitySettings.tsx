import { useState } from 'react';
import AccessibilitySettings from '../AccessibilitySettings';

export default function AccessibilitySettingsExample() {
  const [largeText, setLargeText] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  const [voiceAssist, setVoiceAssist] = useState(false);
  const [hapticFeedback, setHapticFeedback] = useState(true);

  const translations = {
    accessibility: 'Accessibility',
    accessibilityDescription: 'Configure accessibility features for better experience',
    largeText: 'Large Text',
    largeTextDescription: 'Increase text size throughout the app',
    highContrast: 'High Contrast',
    highContrastDescription: 'Enhance color contrast for better visibility',
    voiceAssist: 'Voice Assist',
    voiceAssistDescription: 'Enable voice guidance and announcements',
    hapticFeedback: 'Haptic Feedback',
    hapticFeedbackDescription: 'Vibration feedback for actions and alerts',
  };

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <AccessibilitySettings
        largeText={largeText}
        highContrast={highContrast}
        voiceAssist={voiceAssist}
        hapticFeedback={hapticFeedback}
        onToggleLargeText={(enabled) => {
          setLargeText(enabled);
          console.log('Large Text:', enabled);
        }}
        onToggleHighContrast={(enabled) => {
          setHighContrast(enabled);
          console.log('High Contrast:', enabled);
        }}
        onToggleVoiceAssist={(enabled) => {
          setVoiceAssist(enabled);
          console.log('Voice Assist:', enabled);
        }}
        onToggleHapticFeedback={(enabled) => {
          setHapticFeedback(enabled);
          console.log('Haptic Feedback:', enabled);
        }}
        translations={translations}
      />
    </div>
  );
}
