import AdminDashboard from '../AdminDashboard';

export default function AdminDashboardExample() {
  const mockKYCReviews = [
    {
      id: '1',
      businessName: 'Quick Fix Garage',
      ownerName: 'Rajesh Kumar',
      category: 'Garage',
      status: 'pending' as const,
      submittedDate: '2 hours ago',
    },
    {
      id: '2',
      businessName: 'MRF Tyre Centre',
      ownerName: 'Amit Shah',
      category: 'Tyre Shop',
      status: 'approved' as const,
      submittedDate: '1 day ago',
    },
    {
      id: '3',
      businessName: 'EV Charge Hub',
      ownerName: 'Priya Patel',
      category: 'EV Charging',
      status: 'pending' as const,
      submittedDate: '3 hours ago',
    },
  ];

  const translations = {
    adminDashboard: 'Admin Dashboard',
    totalPartners: 'Total Partners',
    pendingKYC: 'Pending KYC',
    activeOrders: 'Active Orders',
    totalRevenue: 'Total Revenue',
    kycReview: 'KYC Review',
    orders: 'Orders',
    payouts: 'Payouts',
    support: 'Support',
    businessName: 'Business Name',
    owner: 'Owner',
    category: 'Category',
    status: 'Status',
    submitted: 'Submitted',
    approve: 'Approve',
    reject: 'Reject',
    viewDocuments: 'View Docs',
    exportCSV: 'Export CSV',
    pending: 'Pending',
    approved: 'Approved',
    rejected: 'Rejected',
  };

  return (
    <AdminDashboard
      totalPartners={245}
      pendingKYC={12}
      activeOrders={48}
      totalRevenue={2450000}
      kycReviews={mockKYCReviews}
      onApproveKYC={(id) => console.log('Approve KYC:', id)}
      onRejectKYC={(id) => console.log('Reject KYC:', id)}
      translations={translations}
    />
  );
}
