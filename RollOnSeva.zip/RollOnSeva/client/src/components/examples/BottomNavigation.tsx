import { useState } from 'react';
import BottomNavigation, { type NavItem } from '../BottomNavigation';

export default function BottomNavigationExample() {
  const [activeTab, setActiveTab] = useState<NavItem>('nearby');

  const translations = {
    sos: 'SOS',
    nearby: 'Nearby',
    services: 'Services',
    partners: 'Partners',
    profile: 'Profile',
  };

  return (
    <div className="h-screen relative">
      <BottomNavigation
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          console.log('Tab changed to:', tab);
        }}
        translations={translations}
      />
    </div>
  );
}
