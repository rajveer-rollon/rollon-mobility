import { useState } from 'react';
import CategoryFilter, { type ServiceCategory } from '../CategoryFilter';

export default function CategoryFilterExample() {
  const [category, setCategory] = useState<ServiceCategory>('all');

  const translations = {
    all: 'All',
    emergencyAssistance: 'Emergency',
    tyreShop: 'Tyre Shop',
    garage: 'Garage',
    evCharging: 'EV Charging',
    autoParts: 'Auto Parts',
  };

  return (
    <CategoryFilter
      selectedCategory={category}
      onCategoryChange={(cat) => {
        setCategory(cat);
        console.log('Category changed to:', cat);
      }}
      translations={translations}
    />
  );
}
