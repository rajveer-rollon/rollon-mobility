import EmptyState from '../EmptyState';

export default function EmptyStateExample() {
  const translations = {
    noServicesFound: 'No services found nearby',
    tryDifferentLocation: 'Try adjusting your location or filters',
  };

  return (
    <div className="p-4">
      <EmptyState translations={translations} />
    </div>
  );
}
