import Hero from '../Hero';

export default function HeroExample() {
  const translations = {
    appName: 'RollOn Mobility',
    tagline: 'Instant Vehicle Support, Anytime, Anywhere',
    instantHelp: 'Get Instant Help',
    sosDescription: 'Tap the emergency button for immediate roadside assistance',
    trustedPartners: '10,000+ Trusted Partners',
    commissionFree: 'Commission-Free',
  };

  return (
    <Hero
      onGetStarted={() => console.log('Get started clicked')}
      translations={translations}
    />
  );
}
