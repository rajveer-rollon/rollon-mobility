import IndiaMapWatermark from '../IndiaMapWatermark';
import { Card } from '@/components/ui/card';

export default function IndiaMapWatermarkExample() {
  return (
    <Card className="relative min-h-[400px] p-8">
      <IndiaMapWatermark />
      <div className="relative z-10 space-y-4">
        <h2 className="text-2xl font-bold">RollOn Mobility</h2>
        <p className="text-muted-foreground">
          Bharat's Trusted Seva Mission
        </p>
        <p className="text-sm">
          The India map watermark appears subtly in the background
        </p>
      </div>
    </Card>
  );
}
