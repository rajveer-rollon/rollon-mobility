import { useState } from 'react';
import LanguageSelector from '../LanguageSelector';
import { type Language } from '@/lib/i18n';

export default function LanguageSelectorExample() {
  const [language, setLanguage] = useState<Language>('en');

  return (
    <div className="p-4">
      <LanguageSelector 
        currentLanguage={language} 
        onLanguageChange={(lang) => {
          setLanguage(lang);
          console.log('Language changed to:', lang);
        }} 
      />
    </div>
  );
}
