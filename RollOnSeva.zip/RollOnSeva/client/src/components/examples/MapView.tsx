import { useState } from 'react';
import MapView from '../MapView';

export default function MapViewExample() {
  const [location, setLocation] = useState<{ lat: number; lng: number } | undefined>();

  return (
    <div className="p-4">
      <MapView
        userLocation={location}
        onRequestLocation={() => {
          console.log('Requesting location...');
          setLocation({ lat: 23.0225, lng: 72.5714 });
        }}
      />
    </div>
  );
}
