import OTPLogin from '../OTPLogin';

export default function OTPLoginExample() {
  const translations = {
    phoneLogin: 'Partner Login',
    enterPhone: 'Enter your registered phone number',
    phoneNumber: 'Phone Number',
    sendOTP: 'Send OTP',
    enterOTP: 'Enter OTP',
    otpSent: 'OTP sent to your phone',
    verify: 'Verify',
    resendOTP: 'Resend OTP',
  };

  return (
    <div className="p-4">
      <OTPLogin
        onLogin={(phone, otp) => console.log('Login:', { phone, otp })}
        translations={translations}
      />
    </div>
  );
}
