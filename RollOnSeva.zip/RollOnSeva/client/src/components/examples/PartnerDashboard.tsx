import { useState } from 'react';
import PartnerDashboard from '../PartnerDashboard';

export default function PartnerDashboardExample() {
  const [isOnline, setIsOnline] = useState(true);

  const mockOrders = [
    {
      id: '1',
      customerName: 'Rajesh Kumar',
      service: 'Tyre Replacement',
      amount: 3500,
      status: 'in-progress' as const,
      time: '10:30 AM',
    },
    {
      id: '2',
      customerName: 'Priya Patel',
      service: 'Oil Change',
      amount: 800,
      status: 'completed' as const,
      time: '9:15 AM',
    },
    {
      id: '3',
      customerName: 'Amit Shah',
      service: 'Brake Service',
      amount: 2400,
      status: 'pending' as const,
      time: '8:45 AM',
    },
  ];

  const translations = {
    dashboard: 'Partner Dashboard',
    status: 'Status',
    online: 'Online',
    offline: 'Offline',
    todayEarnings: "Today's Earnings",
    totalOrders: 'Total Orders',
    completed: 'Completed',
    pending: 'Pending',
    recentOrders: 'Recent Orders',
    viewAll: 'View All',
    inventory: 'Manage Inventory',
    support: 'Contact Support',
  };

  return (
    <PartnerDashboard
      partnerName="Quick Fix Garage"
      isOnline={isOnline}
      onToggleOnline={(online) => {
        setIsOnline(online);
        console.log('Online status:', online);
      }}
      todayEarnings={12500}
      totalOrders={8}
      completedOrders={5}
      pendingOrders={3}
      recentOrders={mockOrders}
      translations={translations}
    />
  );
}
