import PartnerOnboardingForm from '../PartnerOnboardingForm';

export default function PartnerOnboardingFormExample() {
  const translations = {
    becomePartner: 'Become a Partner',
    registerBusiness: 'Register your business and start earning',
    businessName: 'Business Name',
    ownerName: 'Owner Name',
    phoneNumber: 'Phone Number',
    address: 'Address',
    city: 'City',
    category: 'Category',
    operatingHours: 'Operating Hours',
    submit: 'Submit',
    kycUpload: 'KYC Upload',
    garage: 'Garage',
    tyreShop: 'Tyre Shop',
    evCharging: 'EV Charging',
    autoParts: 'Auto Parts',
    emergencyAssistance: 'Emergency Assistance',
  };

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <PartnerOnboardingForm
        onSubmit={(data) => console.log('Partner registration:', data)}
        translations={translations}
      />
    </div>
  );
}
