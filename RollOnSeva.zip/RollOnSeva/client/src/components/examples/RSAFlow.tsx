import { useState } from 'react';
import RSAFlow from '../RSAFlow';
import { Button } from '@/components/ui/button';

type RSAStatus = 'requesting' | 'assigned' | 'enroute' | 'arrived' | 'completed';

export default function RSAFlowExample() {
  const [status, setStatus] = useState<RSAStatus>('requesting');

  const provider = {
    name: 'Rajesh Kumar - Quick Fix',
    phone: '+91-9876543210',
    vehicle: 'Tata Ace (Service Van)',
    eta: '12 mins',
    distance: '2.3 km',
  };

  const translations = {
    rsaRequest: 'Roadside Assistance',
    requesting: 'Requesting',
    assigned: 'Assigned',
    enroute: 'En Route',
    arrived: 'Arrived',
    completed: 'Completed',
    provider: 'Provider',
    eta: 'ETA',
    distance: 'Distance',
    issue: 'Issue',
    location: 'Location',
    requestedAt: 'Requested At',
    call: 'Call',
    navigate: 'Track',
    cancel: 'Cancel Request',
    findingNearby: 'Finding nearby service providers...',
    onTheWay: 'Provider is on the way to your location',
    providerArrived: 'Provider has arrived at your location',
    serviceCompleted: 'Service completed successfully',
  };

  const statusSteps: RSAStatus[] = ['requesting', 'assigned', 'enroute', 'arrived', 'completed'];

  return (
    <div className="space-y-4">
      <div className="p-4 bg-muted rounded-lg">
        <p className="text-sm font-medium mb-2">Demo Controls:</p>
        <div className="flex gap-2 flex-wrap">
          {statusSteps.map((step) => (
            <Button
              key={step}
              size="sm"
              variant={status === step ? 'default' : 'outline'}
              onClick={() => setStatus(step)}
            >
              {step}
            </Button>
          ))}
        </div>
      </div>

      <RSAFlow
        status={status}
        provider={status !== 'requesting' ? provider : undefined}
        requestTime="10:45 AM"
        location="Highway 8, near Gujarat Industrial Estate, Ahmedabad"
        issue="Flat Tyre - Front Right"
        onCall={() => console.log('Call provider')}
        onNavigate={() => console.log('Navigate to provider')}
        onCancel={() => console.log('Cancel request')}
        translations={translations}
      />
    </div>
  );
}
