import SOSButton from '../SOSButton';

export default function SOSButtonExample() {
  return (
    <SOSButton 
      onEmergency={() => console.log('SOS Emergency activated!')} 
    />
  );
}
