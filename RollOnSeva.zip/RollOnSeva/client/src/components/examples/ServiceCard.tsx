import ServiceCard from '../ServiceCard';

export default function ServiceCardExample() {
  return (
    <div className="p-4 space-y-4 max-w-md">
      <ServiceCard
        id="1"
        businessName="Quick Fix Auto Garage"
        category="Garage"
        services={["Engine Repair", "Oil Change", "Brake Service", "AC Service"]}
        distance={2.3}
        rating={4.5}
        phone="+91-9876543210"
        address="Shop 12, Gujarat Industrial Estate, Ahmedabad"
        operatingHours="9:00 AM - 8:00 PM"
        isVerified={true}
        isOpen={true}
        onCall={(phone) => console.log('Calling:', phone)}
        onNavigate={(id) => console.log('Navigate to:', id)}
        onDetails={(id) => console.log('Show details for:', id)}
      />
      
      <ServiceCard
        id="2"
        businessName="MRF Tyre Centre"
        category="Tyre Shop"
        services={["Tyre Replacement", "Wheel Alignment", "Balancing"]}
        distance={0.8}
        rating={4.8}
        phone="+91-9876543211"
        address="Beside City Mall, Gandhinagar"
        operatingHours="8:00 AM - 9:00 PM"
        isVerified={true}
        isOpen={false}
        onCall={(phone) => console.log('Calling:', phone)}
        onNavigate={(id) => console.log('Navigate to:', id)}
        onDetails={(id) => console.log('Show details for:', id)}
      />
    </div>
  );
}
