import TricolourWave from '../TricolourWave';

export default function TricolourWaveExample() {
  return (
    <div className="space-y-8">
      <div className="bg-card">
        <TricolourWave />
      </div>
      <div className="p-4 text-center">
        <p className="text-sm text-muted-foreground">
          India-themed tricolour wave header
        </p>
      </div>
    </div>
  );
}
