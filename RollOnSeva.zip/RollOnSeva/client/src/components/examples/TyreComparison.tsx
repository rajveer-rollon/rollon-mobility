import TyreComparison from '../TyreComparison';

export default function TyreComparisonExample() {
  const mockDeals = [
    {
      id: '1',
      brand: 'MRF',
      model: 'ZVTS 165/80 R14',
      size: '165/80 R14',
      price: 4500,
      availability: true,
      shopName: 'MRF Exclusive',
      phone: '+91-9876543210',
    },
    {
      id: '2',
      brand: 'CEAT',
      model: 'Milaze 165/80 R14',
      size: '165/80 R14',
      price: 4200,
      availability: true,
      shopName: 'CEAT Shoppe',
      phone: '+91-9876543211',
    },
    {
      id: '3',
      brand: 'Apollo',
      model: 'Amazer 4G 165/80 R14',
      size: '165/80 R14',
      price: 4350,
      availability: false,
      shopName: 'Apollo Tyres',
      phone: '+91-9876543212',
    },
    {
      id: '4',
      brand: 'JK Tyre',
      model: 'Ultima 165/80 R14',
      size: '165/80 R14',
      price: 4100,
      availability: true,
      shopName: 'JK Tyre Shop',
      phone: '+91-9876543213',
    },
  ];

  const translations = {
    tyreComparison: 'Tyre Price Comparison',
    brand: 'Brand',
    model: 'Model',
    size: 'Size',
    price: 'Price',
    availability: 'Availability',
    contactDealer: 'Contact Dealer',
    available: 'Available',
    outOfStock: 'Out of Stock',
  };

  return (
    <div className="p-4">
      <TyreComparison
        deals={mockDeals}
        onContact={(phone) => console.log('Contact dealer:', phone)}
        translations={translations}
      />
    </div>
  );
}
