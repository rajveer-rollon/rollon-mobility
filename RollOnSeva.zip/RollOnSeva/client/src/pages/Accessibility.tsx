import { useState } from "react";
import AccessibilitySettings from "@/components/AccessibilitySettings";
import { translations } from "@/lib/i18n";
import { useLanguage } from "@/contexts/LanguageContext";

export default function AccessibilityPage() {
  const { language } = useLanguage();
  const t = translations[language];
  const [largeText, setLargeText] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  const [voiceAssist, setVoiceAssist] = useState(false);
  const [hapticFeedback, setHapticFeedback] = useState(true);

  return (
    <div className="min-h-screen">
      <AccessibilitySettings
        largeText={largeText}
        highContrast={highContrast}
        voiceAssist={voiceAssist}
        hapticFeedback={hapticFeedback}
        onToggleLargeText={() => setLargeText(!largeText)}
        onToggleHighContrast={() => setHighContrast(!highContrast)}
        onToggleVoiceAssist={() => setVoiceAssist(!voiceAssist)}
        onToggleHapticFeedback={() => setHapticFeedback(!hapticFeedback)}
        translations={{
          accessibility: t.accessibility,
          accessibilityDescription: t.accessibilityDescription,
          largeText: t.largeText,
          largeTextDescription: t.largeTextDescription,
          highContrast: t.highContrast,
          highContrastDescription: t.highContrastDescription,
          voiceAssist: t.voiceAssist,
          voiceAssistDescription: t.voiceAssistDescription,
          hapticFeedback: t.hapticFeedback,
          hapticFeedbackDescription: t.hapticFeedbackDescription,
        }}
      />
    </div>
  );
}
