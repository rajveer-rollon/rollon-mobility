import { useQuery } from "@tanstack/react-query";
import AdminDashboard from "@/components/AdminDashboard";
import { translations } from "@/lib/i18n";
import { useLanguage } from "@/contexts/LanguageContext";
import type { ServiceProvider, PartnerOnboarding, Order } from "@shared/schema";

export default function AdminDashboardPage() {
  const { language } = useLanguage();
  const t = translations[language];
  
  const { data: providers = [] } = useQuery<ServiceProvider[]>({
    queryKey: ["/api/service-providers"],
  });

  const { data: onboardings = [] } = useQuery<PartnerOnboarding[]>({
    queryKey: ["/api/partner-onboarding"],
  });

  const { data: orders = [] } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
  });

  const pendingKYC = onboardings.filter((o: any) => o.status === 'pending');
  const activeOrders = orders.filter((o: any) => o.status !== 'completed');
  const totalRevenue = orders.reduce((sum: number, order: any) => 
    sum + parseFloat(order.amount || 0), 0
  );

  const kycApplications = pendingKYC.map((app) => {
    let businessName = 'N/A';
    if (app.businessData) {
      try {
        const parsed = JSON.parse(app.businessData);
        businessName = parsed.businessName || 'N/A';
      } catch (e) {
        businessName = 'N/A';
      }
    }
    return {
      id: app.id,
      businessName,
      phone: app.phone,
      submittedAt: app.createdAt ? new Date(app.createdAt).toLocaleDateString() : 'N/A',
    };
  });

  return (
    <AdminDashboard
      totalPartners={providers.length}
      pendingKYC={pendingKYC.length}
      activeOrders={activeOrders.length}
      totalRevenue={totalRevenue}
      kycApplications={kycApplications}
      onApproveKYC={() => {}}
      onRejectKYC={() => {}}
      onViewDocuments={() => {}}
      translations={{
        adminDashboard: t.adminDashboard,
        totalPartners: t.partners,
        pendingKYC: t.pendingKYC,
        activeOrders: t.activeOrders,
        totalRevenue: t.totalRevenue,
        kycReview: t.kycReview,
        businessName: t.businessName,
        owner: t.ownerName,
        category: t.category,
        submitted: t.submittedAt,
        approve: t.approve,
        reject: t.rejected,
        orders: t.orders,
        payouts: t.payouts,
        support: t.support,
        status: t.status,
        viewDocuments: t.viewDocuments,
        exportCSV: t.exportCSV,
        pending: t.pending,
        phone: t.phone,
      }}
    />
  );
}
