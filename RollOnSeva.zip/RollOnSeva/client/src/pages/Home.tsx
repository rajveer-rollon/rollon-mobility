import { useState } from "react";
import { translations } from "@/lib/i18n";
import { useLanguage } from "@/contexts/LanguageContext";
import Hero from "@/components/Hero";
import LanguageSelector from "@/components/LanguageSelector";
import BottomNavigation, { type NavItem } from "@/components/BottomNavigation";
import SOSButton from "@/components/SOSButton";
import CategoryFilter, { type ServiceCategory } from "@/components/CategoryFilter";
import ServiceCard from "@/components/ServiceCard";
import PartnerOnboardingForm from "@/components/PartnerOnboardingForm";
import TyreComparison from "@/components/TyreComparison";
import MapView from "@/components/MapView";
import EmptyState from "@/components/EmptyState";
import IndiaMapWatermark from "@/components/IndiaMapWatermark";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";

export default function Home() {
  const { language, setLanguage } = useLanguage();
  const [activeTab, setActiveTab] = useState<NavItem>('nearby');
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategory>('all');
  const [showHero, setShowHero] = useState(true);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | undefined>();
  const { toast } = useToast();

  const t = translations[language];

  const mockServices = [
    {
      id: '1',
      businessName: 'Quick Fix Auto Garage',
      category: 'Garage',
      services: ['Engine Repair', 'Oil Change', 'Brake Service', 'AC Service'],
      distance: 2.3,
      rating: 4.5,
      phone: '+91-9876543210',
      address: 'Shop 12, Gujarat Industrial Estate, Ahmedabad',
      operatingHours: '9:00 AM - 8:00 PM',
      isVerified: true,
      isOpen: true,
    },
    {
      id: '2',
      businessName: 'MRF Tyre Centre',
      category: 'Tyre Shop',
      services: ['Tyre Replacement', 'Wheel Alignment', 'Balancing'],
      distance: 0.8,
      rating: 4.8,
      phone: '+91-9876543211',
      address: 'Beside City Mall, Gandhinagar',
      operatingHours: '8:00 AM - 9:00 PM',
      isVerified: true,
      isOpen: true,
    },
    {
      id: '3',
      businessName: 'EV Charge Hub',
      category: 'EV Charging',
      services: ['Fast Charging', 'Slow Charging', 'Battery Check'],
      distance: 1.5,
      rating: 4.6,
      phone: '+91-9876543212',
      address: 'Highway Plaza, Ahmedabad-Gandhinagar Highway',
      operatingHours: '24/7',
      isVerified: true,
      isOpen: true,
    },
  ];

  const mockTyreDeals = [
    {
      id: '1',
      brand: 'MRF',
      model: 'ZVTS 165/80 R14',
      size: '165/80 R14',
      price: 4500,
      availability: true,
      shopName: 'MRF Exclusive',
      phone: '+91-9876543210',
    },
    {
      id: '2',
      brand: 'CEAT',
      model: 'Milaze 165/80 R14',
      size: '165/80 R14',
      price: 4200,
      availability: true,
      shopName: 'CEAT Shoppe',
      phone: '+91-9876543211',
    },
    {
      id: '3',
      brand: 'Apollo',
      model: 'Amazer 4G 165/80 R14',
      size: '165/80 R14',
      price: 4350,
      availability: false,
      shopName: 'Apollo Tyres',
      phone: '+91-9876543212',
    },
  ];

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
    toast({
      title: "Calling...",
      description: `Initiating call to ${phone}`,
    });
  };

  const handleNavigate = (id: string) => {
    const service = mockServices.find(s => s.id === id);
    if (service) {
      toast({
        title: "Opening Maps",
        description: `Navigating to ${service.businessName}`,
      });
    }
  };

  const handleDetails = (id: string) => {
    const service = mockServices.find(s => s.id === id);
    if (service) {
      toast({
        title: service.businessName,
        description: service.address,
      });
    }
  };

  const handleSOS = () => {
    toast({
      title: "SOS Activated",
      description: "Finding nearest emergency service providers...",
      variant: "destructive",
    });
    setActiveTab('nearby');
    setShowHero(false);
  };

  const handleRequestLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          toast({
            title: "Location Enabled",
            description: "Finding services near you...",
          });
        },
        () => {
          setUserLocation({ lat: 23.0225, lng: 72.5714 });
          toast({
            title: "Location Enabled",
            description: "Using default location: Ahmedabad",
          });
        }
      );
    }
  };

  if (showHero) {
    return (
      <>
        <div className="fixed top-4 right-4 z-50">
          <LanguageSelector
            currentLanguage={language}
            onLanguageChange={setLanguage}
          />
        </div>
        <Hero
          onGetStarted={() => {
            setShowHero(false);
            handleRequestLocation();
          }}
          translations={t}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20 relative">
      <IndiaMapWatermark />
      <header className="sticky top-0 z-30 bg-card border-b border-card-border">
        <div className="flex items-center justify-between px-4 py-3">
          <h1 className="text-xl font-bold text-foreground">{t.appName}</h1>
          <LanguageSelector
            currentLanguage={language}
            onLanguageChange={setLanguage}
          />
        </div>
      </header>

      {activeTab === 'sos' && (
        <div className="p-6 space-y-6">
          <div className="text-center space-y-4">
            <h2 className="text-2xl font-bold text-destructive">{t.sos}</h2>
            <p className="text-muted-foreground">{t.sosDescription}</p>
            <Button
              variant="destructive"
              size="lg"
              className="w-full max-w-md"
              onClick={handleSOS}
              data-testid="button-activate-sos"
            >
              {t.instantHelp}
            </Button>
          </div>
        </div>
      )}

      {activeTab === 'nearby' && (
        <div className="space-y-4">
          <div className="p-4">
            <MapView
              userLocation={userLocation}
              onRequestLocation={handleRequestLocation}
            />
          </div>

          <CategoryFilter
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
            translations={t}
          />

          <div className="px-4 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">{t.findServices}</h2>
              <Button variant="ghost" size="icon">
                <Search className="h-5 w-5" />
              </Button>
            </div>

            {mockServices.map((service) => (
              <ServiceCard
                key={service.id}
                {...service}
                onCall={handleCall}
                onNavigate={handleNavigate}
                onDetails={handleDetails}
              />
            ))}
          </div>
        </div>
      )}

      {activeTab === 'services' && (
        <div className="p-4 space-y-6">
          <TyreComparison
            deals={mockTyreDeals}
            onContact={handleCall}
            translations={t}
          />
          
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">{t.services}</h2>
            {mockServices.map((service) => (
              <ServiceCard
                key={service.id}
                {...service}
                onCall={handleCall}
                onNavigate={handleNavigate}
                onDetails={handleDetails}
              />
            ))}
          </div>
        </div>
      )}

      {activeTab === 'partners' && (
        <div className="p-4">
          <PartnerOnboardingForm
            onSubmit={(data) => {
              console.log('Partner registration:', data);
              toast({
                title: "Registration Submitted",
                description: "We'll review your application and contact you soon.",
              });
            }}
            translations={t}
          />
        </div>
      )}

      {activeTab === 'profile' && (
        <div className="p-6">
          <EmptyState translations={t} />
        </div>
      )}

      <SOSButton onEmergency={handleSOS} />
      <BottomNavigation
        activeTab={activeTab}
        onTabChange={setActiveTab}
        translations={t}
      />
    </div>
  );
}
