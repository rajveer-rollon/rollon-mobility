import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import PartnerDashboard from "@/components/PartnerDashboard";
import { translations } from "@/lib/i18n";
import { useLanguage } from "@/contexts/LanguageContext";
import type { Order } from "@shared/schema";

export default function PartnerDashboardPage() {
  const { language } = useLanguage();
  const t = translations[language];
  const [isOnline, setIsOnline] = useState(true);
  
  const { data: orders = [] } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
  });

  const recentOrders = orders.slice(0, 3).map((order) => ({
    id: order.id,
    customerName: order.customerName,
    service: order.service,
    amount: parseFloat(order.amount),
    status: (order.status as 'pending' | 'in-progress' | 'completed' | 'cancelled'),
    time: order.createdAt ? new Date(order.createdAt).toLocaleTimeString() : 'N/A',
  }));

  const todayOrders = orders.filter((order: any) => {
    const orderDate = new Date(order.createdAt);
    const today = new Date();
    return orderDate.toDateString() === today.toDateString();
  });

  const todayEarnings = todayOrders.reduce((sum: number, order: any) => 
    sum + parseFloat(order.amount), 0
  );

  const completedToday = todayOrders.filter((o: any) => o.status === 'completed').length;
  const pendingOrders = orders.filter((o: any) => o.status === 'pending').length;

  return (
    <PartnerDashboard
      partnerName="Rajesh Kumar"
      isOnline={isOnline}
      onToggleOnline={() => setIsOnline(!isOnline)}
      todayEarnings={todayEarnings}
      totalOrders={orders.length}
      completedOrders={completedToday}
      pendingOrders={pendingOrders}
      recentOrders={recentOrders}
      translations={{
        dashboard: t.partnerDashboard,
        status: t.status,
        online: t.online,
        offline: t.offline,
        todayEarnings: t.todayEarnings,
        totalOrders: t.orders,
        completed: t.completed,
        pending: t.pending,
        recentOrders: t.recentOrders,
        viewAll: t.viewAll,
        inventory: t.inventory,
        support: t.support,
      }}
    />
  );
}
