import { useLocation } from "wouter";
import OTPLogin from "@/components/OTPLogin";
import { translations } from "@/lib/i18n";
import { useLanguage } from "@/contexts/LanguageContext";

export default function PartnerLoginPage() {
  const { language } = useLanguage();
  const t = translations[language];
  const [, setLocation] = useLocation();

  const handleLogin = () => {
    setLocation("/partner/dashboard");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <OTPLogin
        onLogin={handleLogin}
        translations={{
          phoneLogin: t.phoneLogin,
          enterPhone: t.enterPhone,
          phoneNumber: t.phoneNumber,
          sendOTP: t.sendOTP,
          enterOTP: t.enterOTP,
          otpSent: t.otpSent,
          verify: t.verify,
          resendOTP: t.resendOTP,
        }}
      />
    </div>
  );
}
