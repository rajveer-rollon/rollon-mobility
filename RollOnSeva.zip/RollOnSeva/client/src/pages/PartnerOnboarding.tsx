import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import PartnerOnboardingForm from "@/components/PartnerOnboardingForm";
import { translations } from "@/lib/i18n";
import { useLanguage } from "@/contexts/LanguageContext";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function PartnerOnboardingPage() {
  const { language } = useLanguage();
  const t = translations[language];
  const [, setLocation] = useLocation();

  const createOnboarding = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("/api/partner-onboarding", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/partner-onboarding"] });
      setLocation("/partner/login");
    },
  });

  return (
    <div className="min-h-screen">
      <PartnerOnboardingForm
        onSubmit={(data) => createOnboarding.mutate(data)}
        translations={{
          becomePartner: t.becomePartner,
          registerBusiness: t.registerBusiness,
          businessName: t.businessName,
          ownerName: t.ownerName,
          phoneNumber: t.phoneNumber,
          address: t.address,
          city: t.city,
          category: t.category,
          operatingHours: t.operatingHours,
          submit: t.submit,
          kycUpload: t.kycUpload,
          garage: t.garage,
          tyreShop: t.tyreShop,
          evCharging: t.evCharging,
          autoParts: t.autoParts,
          emergencyAssistance: t.emergencyAssistance,
        }}
      />
    </div>
  );
}
