import { useState } from "react";
import RSAFlow from "@/components/RSAFlow";
import { translations } from "@/lib/i18n";
import { useLanguage } from "@/contexts/LanguageContext";

export default function RSAPage() {
  const { language } = useLanguage();
  const t = translations[language];
  const [status] = useState<'requesting' | 'assigned' | 'enroute' | 'arrived' | 'completed'>('requesting');

  return (
    <RSAFlow
      status={status}
      requestTime={new Date().toISOString()}
      location="Ahmedabad, Gujarat"
      issue="Flat Tyre"
      translations={{
        rsaRequest: t.rsaRequest,
        requesting: t.requesting,
        assigned: t.findingNearby,
        enroute: t.enroute,
        arrived: t.providerArrived,
        completed: t.serviceCompleted,
        provider: t.partnerName,
        eta: t.eta,
        distance: t.distance,
        issue: t.issue,
        location: t.location,
        requestedAt: t.requestedAt,
        onTheWay: t.onTheWay,
        call: t.call,
        navigate: t.navigate,
        cancel: t.cancel,
        findingNearby: t.findingNearby,
        providerArrived: t.providerArrived,
        serviceCompleted: t.serviceCompleted,
      }}
    />
  );
}
