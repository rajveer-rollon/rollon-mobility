# RollOn Mobility Design Guidelines

## Design Approach
**Material Design System** - Selected for mobile-first utility, familiar Android patterns across India, strong accessibility support, and clear information hierarchy essential for emergency services.

## Core Principles
- **Trust & Clarity**: Emergency services demand instant comprehension and reliability
- **Mobile-First**: Optimized for one-handed use during roadside situations
- **Cultural Context**: Design for diverse Indian users, varied literacy levels, and multilingual needs

## Typography
**Font Stack**: Noto Sans (excellent multilingual support for Hindi/Gujarati)
- **Hero/Headers**: 2xl to 4xl, semibold - commanding presence for SOS features
- **Body Text**: base to lg, regular - optimal readability in bright outdoor conditions
- **Service Labels**: sm, medium - compact information density for listings
- **CTA Buttons**: lg, semibold - clear action labels

## Layout System
**Spacing Units**: Tailwind 3, 4, 6, 8, 12 for consistent rhythm
- Mobile padding: px-4, py-6
- Section spacing: space-y-6 to space-y-8
- Card spacing: p-4 to p-6
- Map containers: Full-width sections with minimal chrome

## Component Library

### Navigation
**Bottom Navigation Bar** (mobile-primary):
- 5 tabs: SOS | Nearby | Services | Partners | Profile
- Fixed bottom position with safe-area support
- Active state with indicator line and icon fill

### Hero Section (Landing/Onboarding)
**Image**: Dynamic illustration showing diverse Indian vehicles (auto, bike, car, truck) with service providers helping citizens - conveys mission and inclusivity
- Full-screen on mobile (h-screen)
- SOS emergency button prominently overlaid (bottom-center, blurred background)

### Core Components

**SOS Emergency Button**:
- Large circular FAB (floating action button), min-w-20, h-20
- Positioned bottom-right with safe margin (bottom-24, right-6)
- Pulsing animation on tap to confirm activation
- Single tap activates emergency flow

**Service Cards**:
- Shadow-md, rounded-xl cards
- Provider photo/logo (top, w-full aspect-video)
- Service name (text-lg, font-semibold)
- Rating stars + distance (text-sm)
- Quick actions row: Call | Navigate | Details (icon buttons)
- Operating hours badge (top-right overlay)

**Map Integration**:
- Full-width map sections (h-96 on mobile)
- Custom markers for service categories (different icon shapes)
- Bottom sheet overlay for selected provider details
- Cluster markers when multiple services nearby

**Service Provider Listings**:
- List/Grid toggle (default: list for information density)
- Filter chips row (horizontal scroll): All | Open Now | Rated 4+ | <5km
- Sort dropdown: Distance | Rating | Price

**Partner Onboarding Form**:
- Multi-step stepper (Material stepper component)
- Steps: Business Details | Services Offered | KYC Upload | Bank Details
- Document upload with camera + gallery options
- Progress indicator (top, showing step X/4)

**Tyre Comparison Table**:
- Horizontal scroll cards (mobile)
- Sticky header row with brand/model
- Price, rating, availability rows
- "Contact Dealer" CTA per column

**Language Selector**:
- Dropdown in header (globe icon)
- Options: English | हिंदी | ગુજરાતી
- Persistent selection across sessions

### Forms & Inputs
- Outlined text fields (Material style)
- Helper text below inputs for multilingual guidance
- Required field indicators (asterisk)
- Error states with clear messaging
- Large touch targets (min-h-12)

## Accessibility Features
- ARIA labels for all interactive elements
- Screen reader announcements for SOS activation
- High contrast mode support
- Minimum touch target 44x44px
- Focus indicators (2px ring offset)
- Alternative text for all service provider images

## Images
**Required Images**:
1. **Hero**: Diverse Indian roadside assistance scene (mechanics, drivers, various vehicles) - conveys trust and inclusivity
2. **Category Icons**: Simple illustrations for service types (wrench, tyre, EV plug, parts)
3. **Empty States**: Friendly illustrations when no services found nearby
4. **Partner Success Stories**: Real photos of registered service providers (builds trust)

**Image Treatment**:
- Rounded corners (rounded-lg) for all photos
- Aspect ratios: 16:9 for provider photos, 1:1 for profile images
- Skeleton loaders while images load

## Animations
**Minimal & Purposeful**:
- SOS button pulse (attention-grabbing)
- Slide-up bottom sheets (service details)
- Fade transitions for page navigation
- Skeleton loading states
- No decorative animations that slow emergency actions

## Mobile Optimization
- Safe area insets for notched devices
- Offline mode indicators
- Location permission prompts (clear messaging)
- Click-to-call (tel: links)
- Click-to-navigate (maps: scheme with Google Maps fallback)
- PWA manifest for home screen installation

## Trust Elements
- Verified badge for KYC-approved partners
- User ratings prominently displayed
- Response time indicators
- "Commission-free" messaging (builds user confidence)
- Partner count badges ("10,000+ trusted partners")