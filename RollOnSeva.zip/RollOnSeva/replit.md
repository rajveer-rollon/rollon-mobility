# RollOn Mobility - Bharat Seva Mission

## Overview
RollOn Mobility is a Bharat-first vehicle support services platform connecting citizens with nearby tyre shops, garages, EV charging stations, and roadside assistance providers across India. The application features patriotic India-themed branding with saffron, green, and navy colors, tricolour wave headers, and comprehensive accessibility features.

## Recent Changes (November 5, 2025)
- Implemented complete India-themed design system with saffron (#FF6F00), green (#008D3C), and navy (#0B2A3B) colors
- Created TricolourWave and IndiaMapWatermark components for patriotic branding
- Built Partner Dashboard with earnings tracking, online/offline toggle, and order management
- Implemented OTP-based partner authentication flow
- Created Admin Dashboard with KYC review, partner approval, and payout management
- Added comprehensive accessibility settings (large text, high contrast, voice assist, haptic feedback)
- Implemented RSA (Roadside Assistance) flow with real-time status tracking
- Extended backend with complete data models for orders, RSA requests, partner onboarding, and KYC management
- Added API routes with Zod validation for all CRUD operations

## Project Architecture

### Frontend (React + Vite + TypeScript)
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side navigation
- **State Management**: TanStack Query v5 for server state
- **UI Components**: Shadcn UI + Radix UI primitives
- **Styling**: Tailwind CSS with custom India-themed color system
- **Internationalization**: English, Hindi, and Gujarati support via i18n system

### Backend (Express + TypeScript)
- **Runtime**: Node.js with Express
- **Storage**: In-memory storage with comprehensive CRUD interface
- **Validation**: Zod schemas for all API endpoints
- **Architecture**: Thin routes layer delegating to storage interface

### Data Models
1. **Service Providers**: Garages, tyre shops, EV charging stations with location-based filtering
2. **Tyre Deals**: Product listings with pricing and availability
3. **Orders**: Customer orders with status tracking
4. **RSA Requests**: Emergency roadside assistance requests with live status
5. **Partner Onboarding**: KYC document management and approval workflow

## Key Features

### User Features
- **SOS Emergency Button**: Quick access to roadside assistance
- **Location-Based Discovery**: Find nearby service providers using geolocation
- **Category Filters**: Filter by tyre shops, garages, EV charging, RSA
- **Multilingual Support**: English, Hindi, Gujarati translations
- **Accessibility**: Large text, high contrast, voice assist, haptic feedback
- **Tricolour Branding**: India-themed design with saffron, green, navy colors

### Partner Features
- **Dashboard**: View earnings, orders, and service requests
- **Online/Offline Toggle**: Control availability
- **OTP Authentication**: Secure phone-based login
- **Onboarding Flow**: Document upload for ID, shop photo, GST/PAN, bank/UPI
- **Inventory Management**: Manage service offerings and pricing

### Admin Features
- **KYC Review**: Approve or reject partner applications
- **Order Management**: Monitor all transactions
- **Payout Tracking**: Manage partner payments
- **Analytics**: View platform statistics

## Color System

### Primary Colors
- **Saffron**: `#FF6F00` - Primary brand color, CTA buttons, accents
- **Green**: `#008D3C` - Success states, verified badges
- **Navy**: `#0B2A3B` - Text, headers, professional elements

### UI Colors
- **Background**: Light gray (#F8F9FA) in light mode, dark (#1A1A1A) in dark mode
- **Cards**: White with subtle shadows
- **Borders**: Subtle gray tones for separation

## API Endpoints

### Service Providers
- `GET /api/service-providers` - List all providers (with optional filters: category, lat, lng, radius)
- `GET /api/service-providers/:id` - Get provider details
- `POST /api/service-providers` - Create provider (validated)
- `PATCH /api/service-providers/:id` - Update provider (validated)

### Orders
- `GET /api/orders` - List orders (with optional providerId filter)
- `POST /api/orders` - Create order (validated)
- `PATCH /api/orders/:id/status` - Update order status

### RSA Requests
- `GET /api/rsa-requests` - List all RSA requests
- `POST /api/rsa-requests` - Create RSA request (validated)
- `PATCH /api/rsa-requests/:id` - Update RSA request status

### Partner Onboarding
- `GET /api/partner-onboarding` - List onboardings (with optional phone/status filters)
- `POST /api/partner-onboarding` - Create onboarding application (validated)
- `PATCH /api/partner-onboarding/:id` - Update onboarding status

### Tyre Deals
- `GET /api/tyre-deals` - List tyre deals (with optional providerId filter)
- `POST /api/tyre-deals` - Create tyre deal (validated)

## Component Structure

### Core Components
- `Hero.tsx` - Landing page hero with tricolour wave
- `TricolourWave.tsx` - Animated India flag wave header
- `IndiaMapWatermark.tsx` - Subtle India map background
- `ServiceCard.tsx` - Service provider display card
- `CategoryFilter.tsx` - Service category selector
- `MapView.tsx` - Location-based provider map

### Dashboard Components
- `PartnerDashboard.tsx` - Partner earnings and orders
- `AdminDashboard.tsx` - Admin KYC and analytics
- `OTPLogin.tsx` - Phone-based authentication
- `AccessibilitySettings.tsx` - PWD-friendly controls
- `RSAFlow.tsx` - Emergency assistance workflow

### Form Components
- `PartnerOnboardingForm.tsx` - Multi-step partner registration
- `TyreComparison.tsx` - Product comparison tool

## Development Guidelines

### Design Principles
- **India-First**: Tricolour elements, patriotic design language
- **Accessibility**: Large touch targets, high contrast, screen reader support
- **Mobile-First**: Bottom navigation, responsive design
- **Multilingual**: All text through i18n system
- **Performance**: Optimized images, lazy loading, efficient queries

### Coding Standards
- TypeScript strict mode enabled
- Zod validation on all API mutations
- TanStack Query for all server state
- Shadcn UI components for consistency
- Tailwind utility classes for styling

## Running the Project
```bash
npm run dev
```
Server runs on port 5000 with Vite HMR for frontend development.

## Mission
RollOn Mobility serves as a digital infrastructure for India's vehicle support ecosystem, empowering local mechanics, tyre shops, and service providers while delivering instant help to citizens across Bharat.
