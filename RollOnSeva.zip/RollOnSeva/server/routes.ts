import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertServiceProviderSchema,
  updateServiceProviderSchema,
  insertTyreDealSchema,
  insertOrderSchema,
  insertRSARequestSchema,
  insertPartnerOnboardingSchema,
  updateOrderStatusSchema,
  updateRSARequestSchema,
  updatePartnerOnboardingSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/service-providers", async (req, res) => {
    try {
      const { category, lat, lng, radius } = req.query;
      
      let providers;
      if (lat && lng && radius) {
        providers = await storage.getNearbyServiceProviders(
          parseFloat(lat as string),
          parseFloat(lng as string),
          parseFloat(radius as string)
        );
      } else if (category && category !== 'all') {
        providers = await storage.getServiceProvidersByCategory(category as string);
      } else {
        providers = await storage.getAllServiceProviders();
      }
      
      res.json(providers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch service providers" });
    }
  });

  app.get("/api/service-providers/:id", async (req, res) => {
    try {
      const provider = await storage.getServiceProvider(req.params.id);
      if (!provider) {
        return res.status(404).json({ error: "Service provider not found" });
      }
      res.json(provider);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch service provider" });
    }
  });

  app.post("/api/service-providers", async (req, res) => {
    try {
      const validatedData = insertServiceProviderSchema.parse(req.body);
      const provider = await storage.createServiceProvider(validatedData);
      res.status(201).json(provider);
    } catch (error) {
      res.status(400).json({ error: "Invalid service provider data" });
    }
  });

  app.patch("/api/service-providers/:id", async (req, res) => {
    try {
      const validatedData = updateServiceProviderSchema.parse(req.body);
      const updated = await storage.updateServiceProvider(req.params.id, validatedData);
      if (!updated) {
        return res.status(404).json({ error: "Service provider not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(400).json({ error: "Invalid update data" });
    }
  });

  app.get("/api/tyre-deals", async (req, res) => {
    try {
      const { providerId } = req.query;
      
      let deals;
      if (providerId) {
        deals = await storage.getTyreDealsByProvider(providerId as string);
      } else {
        deals = await storage.getAllTyreDeals();
      }
      
      res.json(deals);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch tyre deals" });
    }
  });

  app.post("/api/tyre-deals", async (req, res) => {
    try {
      const validatedData = insertTyreDealSchema.parse(req.body);
      const deal = await storage.createTyreDeal(validatedData);
      res.status(201).json(deal);
    } catch (error) {
      res.status(400).json({ error: "Invalid tyre deal data" });
    }
  });

  app.get("/api/orders", async (req, res) => {
    try {
      const { providerId } = req.query;
      
      let orders;
      if (providerId) {
        orders = await storage.getOrdersByProvider(providerId as string);
      } else {
        orders = await storage.getAllOrders();
      }
      
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const validatedData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(validatedData);
      res.status(201).json(order);
    } catch (error) {
      res.status(400).json({ error: "Invalid order data" });
    }
  });

  app.patch("/api/orders/:id/status", async (req, res) => {
    try {
      const validatedData = updateOrderStatusSchema.parse(req.body);
      const updated = await storage.updateOrderStatus(req.params.id, validatedData.status);
      if (!updated) {
        return res.status(404).json({ error: "Order not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(400).json({ error: "Invalid status data" });
    }
  });

  app.get("/api/rsa-requests", async (req, res) => {
    try {
      const requests = await storage.getAllRSARequests();
      res.json(requests);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch RSA requests" });
    }
  });

  app.post("/api/rsa-requests", async (req, res) => {
    try {
      const validatedData = insertRSARequestSchema.parse(req.body);
      const request = await storage.createRSARequest(validatedData);
      res.status(201).json(request);
    } catch (error) {
      res.status(400).json({ error: "Invalid RSA request data" });
    }
  });

  app.patch("/api/rsa-requests/:id", async (req, res) => {
    try {
      const validatedData = updateRSARequestSchema.parse(req.body);
      const updated = await storage.updateRSARequest(req.params.id, validatedData);
      if (!updated) {
        return res.status(404).json({ error: "RSA request not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(400).json({ error: "Invalid RSA request update data" });
    }
  });

  app.get("/api/partner-onboarding", async (req, res) => {
    try {
      const { status, phone } = req.query;
      
      let onboardings;
      if (phone) {
        const onboarding = await storage.getPartnerOnboardingByPhone(phone as string);
        onboardings = onboarding ? [onboarding] : [];
      } else if (status === 'pending') {
        onboardings = await storage.getPendingOnboardings();
      } else {
        onboardings = await storage.getAllPartnerOnboardings();
      }
      
      res.json(onboardings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch partner onboardings" });
    }
  });

  app.post("/api/partner-onboarding", async (req, res) => {
    try {
      const validatedData = insertPartnerOnboardingSchema.parse(req.body);
      const onboarding = await storage.createPartnerOnboarding(validatedData);
      res.status(201).json(onboarding);
    } catch (error) {
      res.status(400).json({ error: "Invalid partner onboarding data" });
    }
  });

  app.patch("/api/partner-onboarding/:id", async (req, res) => {
    try {
      const validatedData = updatePartnerOnboardingSchema.parse(req.body);
      const updated = await storage.updatePartnerOnboarding(req.params.id, validatedData);
      if (!updated) {
        return res.status(404).json({ error: "Partner onboarding not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(400).json({ error: "Invalid partner onboarding update data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
