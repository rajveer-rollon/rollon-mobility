import {
  type User, type InsertUser,
  type ServiceProvider, type InsertServiceProvider, type UpdateServiceProvider,
  type TyreDeal, type InsertTyreDeal,
  type Order, type InsertOrder,
  type RSARequest, type InsertRSARequest,
  type PartnerOnboarding, type InsertPartnerOnboarding
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getServiceProvider(id: string): Promise<ServiceProvider | undefined>;
  getAllServiceProviders(): Promise<ServiceProvider[]>;
  getServiceProvidersByCategory(category: string): Promise<ServiceProvider[]>;
  getNearbyServiceProviders(lat: number, lng: number, radius: number): Promise<ServiceProvider[]>;
  createServiceProvider(provider: InsertServiceProvider): Promise<ServiceProvider>;
  updateServiceProvider(id: string, provider: UpdateServiceProvider): Promise<ServiceProvider | undefined>;
  
  getTyreDeal(id: string): Promise<TyreDeal | undefined>;
  getAllTyreDeals(): Promise<TyreDeal[]>;
  getTyreDealsByProvider(providerId: string): Promise<TyreDeal[]>;
  createTyreDeal(deal: InsertTyreDeal): Promise<TyreDeal>;
  
  getOrder(id: string): Promise<Order | undefined>;
  getAllOrders(): Promise<Order[]>;
  getOrdersByProvider(providerId: string): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<Order | undefined>;
  
  getRSARequest(id: string): Promise<RSARequest | undefined>;
  getAllRSARequests(): Promise<RSARequest[]>;
  createRSARequest(request: InsertRSARequest): Promise<RSARequest>;
  updateRSARequest(id: string, updates: Partial<RSARequest>): Promise<RSARequest | undefined>;
  
  getPartnerOnboarding(id: string): Promise<PartnerOnboarding | undefined>;
  getPartnerOnboardingByPhone(phone: string): Promise<PartnerOnboarding | undefined>;
  getAllPartnerOnboardings(): Promise<PartnerOnboarding[]>;
  getPendingOnboardings(): Promise<PartnerOnboarding[]>;
  createPartnerOnboarding(onboarding: InsertPartnerOnboarding): Promise<PartnerOnboarding>;
  updatePartnerOnboarding(id: string, updates: Partial<PartnerOnboarding>): Promise<PartnerOnboarding | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private serviceProviders: Map<string, ServiceProvider>;
  private tyreDeals: Map<string, TyreDeal>;
  private orders: Map<string, Order>;
  private rsaRequests: Map<string, RSARequest>;
  private partnerOnboardings: Map<string, PartnerOnboarding>;

  constructor() {
    this.users = new Map();
    this.serviceProviders = new Map();
    this.tyreDeals = new Map();
    this.orders = new Map();
    this.rsaRequests = new Map();
    this.partnerOnboardings = new Map();
    
    this.seedData();
  }

  private seedData() {
    const mockProviders: ServiceProvider[] = [
      {
        id: randomUUID(),
        businessName: "Quick Fix Auto Garage",
        ownerName: "Rajesh Kumar",
        phone: "+91-9876543210",
        category: "garage",
        services: ["Engine Repair", "Oil Change", "Brake Service", "AC Service"],
        latitude: "23.0225",
        longitude: "72.5714",
        address: "Shop 12, Gujarat Industrial Estate, Ahmedabad",
        city: "Ahmedabad",
        operatingHours: "9:00 AM - 8:00 PM",
        isVerified: true,
        rating: "4.5",
        kycDocument: null,
        createdAt: new Date(),
      },
      {
        id: randomUUID(),
        businessName: "MRF Tyre Centre",
        ownerName: "Amit Shah",
        phone: "+91-9876543211",
        category: "tyre",
        services: ["Tyre Replacement", "Wheel Alignment", "Balancing"],
        latitude: "23.0850",
        longitude: "72.6360",
        address: "Beside City Mall, Gandhinagar",
        city: "Gandhinagar",
        operatingHours: "8:00 AM - 9:00 PM",
        isVerified: true,
        rating: "4.8",
        kycDocument: null,
        createdAt: new Date(),
      },
      {
        id: randomUUID(),
        businessName: "EV Charge Hub",
        ownerName: "Priya Patel",
        phone: "+91-9876543212",
        category: "ev",
        services: ["Fast Charging", "Slow Charging", "Battery Check"],
        latitude: "23.0500",
        longitude: "72.6000",
        address: "Highway Plaza, Ahmedabad-Gandhinagar Highway",
        city: "Ahmedabad",
        operatingHours: "24/7",
        isVerified: true,
        rating: "4.6",
        kycDocument: null,
        createdAt: new Date(),
      },
    ];

    mockProviders.forEach(provider => {
      this.serviceProviders.set(provider.id, provider);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getServiceProvider(id: string): Promise<ServiceProvider | undefined> {
    return this.serviceProviders.get(id);
  }

  async getAllServiceProviders(): Promise<ServiceProvider[]> {
    return Array.from(this.serviceProviders.values());
  }

  async getServiceProvidersByCategory(category: string): Promise<ServiceProvider[]> {
    return Array.from(this.serviceProviders.values()).filter(
      (provider) => provider.category === category
    );
  }

  async getNearbyServiceProviders(lat: number, lng: number, radius: number): Promise<ServiceProvider[]> {
    return Array.from(this.serviceProviders.values()).filter(provider => {
      const providerLat = parseFloat(provider.latitude);
      const providerLng = parseFloat(provider.longitude);
      const distance = this.calculateDistance(lat, lng, providerLat, providerLng);
      return distance <= radius;
    });
  }

  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371;
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private deg2rad(deg: number): number {
    return deg * (Math.PI / 180);
  }

  async createServiceProvider(insertProvider: InsertServiceProvider): Promise<ServiceProvider> {
    const id = randomUUID();
    const provider: ServiceProvider = {
      ...insertProvider,
      operatingHours: insertProvider.operatingHours ?? null,
      kycDocument: insertProvider.kycDocument ?? null,
      id,
      isVerified: false,
      rating: null,
      createdAt: new Date(),
    };
    this.serviceProviders.set(id, provider);
    return provider;
  }

  async updateServiceProvider(id: string, updates: UpdateServiceProvider): Promise<ServiceProvider | undefined> {
    const provider = this.serviceProviders.get(id);
    if (!provider) return undefined;
    
    const updated = { ...provider, ...updates };
    this.serviceProviders.set(id, updated);
    return updated;
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getAllOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrdersByProvider(providerId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.providerId === providerId
    );
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = {
      ...insertOrder,
      id,
      createdAt: new Date(),
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrderStatus(id: string, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updated = { ...order, status };
    this.orders.set(id, updated);
    return updated;
  }

  async getRSARequest(id: string): Promise<RSARequest | undefined> {
    return this.rsaRequests.get(id);
  }

  async getAllRSARequests(): Promise<RSARequest[]> {
    return Array.from(this.rsaRequests.values());
  }

  async createRSARequest(insertRequest: InsertRSARequest): Promise<RSARequest> {
    const id = randomUUID();
    const request: RSARequest = {
      ...insertRequest,
      providerId: insertRequest.providerId ?? null,
      id,
      createdAt: new Date(),
    };
    this.rsaRequests.set(id, request);
    return request;
  }

  async updateRSARequest(id: string, updates: Partial<RSARequest>): Promise<RSARequest | undefined> {
    const request = this.rsaRequests.get(id);
    if (!request) return undefined;
    
    const updated = { ...request, ...updates };
    this.rsaRequests.set(id, updated);
    return updated;
  }

  async getPartnerOnboarding(id: string): Promise<PartnerOnboarding | undefined> {
    return this.partnerOnboardings.get(id);
  }

  async getPartnerOnboardingByPhone(phone: string): Promise<PartnerOnboarding | undefined> {
    return Array.from(this.partnerOnboardings.values()).find(
      (onboarding) => onboarding.phone === phone
    );
  }

  async getAllPartnerOnboardings(): Promise<PartnerOnboarding[]> {
    return Array.from(this.partnerOnboardings.values());
  }

  async getPendingOnboardings(): Promise<PartnerOnboarding[]> {
    return Array.from(this.partnerOnboardings.values()).filter(
      (onboarding) => onboarding.status === 'pending'
    );
  }

  async createPartnerOnboarding(insertOnboarding: InsertPartnerOnboarding): Promise<PartnerOnboarding> {
    const id = randomUUID();
    const onboarding: PartnerOnboarding = {
      ...insertOnboarding,
      businessData: insertOnboarding.businessData ?? null,
      kycDocuments: insertOnboarding.kycDocuments ?? null,
      rejectionReason: insertOnboarding.rejectionReason ?? null,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.partnerOnboardings.set(id, onboarding);
    return onboarding;
  }

  async updatePartnerOnboarding(id: string, updates: Partial<PartnerOnboarding>): Promise<PartnerOnboarding | undefined> {
    const onboarding = this.partnerOnboardings.get(id);
    if (!onboarding) return undefined;
    
    const updated = { ...onboarding, ...updates, updatedAt: new Date() };
    this.partnerOnboardings.set(id, updated);
    return updated;
  }

  async getTyreDeal(id: string): Promise<TyreDeal | undefined> {
    return this.tyreDeals.get(id);
  }

  async getAllTyreDeals(): Promise<TyreDeal[]> {
    return Array.from(this.tyreDeals.values());
  }

  async getTyreDealsByProvider(providerId: string): Promise<TyreDeal[]> {
    return Array.from(this.tyreDeals.values()).filter(
      (deal) => deal.providerId === providerId
    );
  }

  async createTyreDeal(insertDeal: InsertTyreDeal): Promise<TyreDeal> {
    const id = randomUUID();
    const deal: TyreDeal = {
      ...insertDeal,
      providerId: insertDeal.providerId ?? null,
      availability: insertDeal.availability ?? null,
      id,
    };
    this.tyreDeals.set(id, deal);
    return deal;
  }
}

export const storage = new MemStorage();
