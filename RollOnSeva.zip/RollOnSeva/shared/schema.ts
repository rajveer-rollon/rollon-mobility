import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const serviceProviders = pgTable("service_providers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  businessName: text("business_name").notNull(),
  ownerName: text("owner_name").notNull(),
  phone: text("phone").notNull(),
  category: text("category").notNull(),
  services: text("services").array().notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 7 }).notNull(),
  longitude: decimal("longitude", { precision: 10, scale: 7 }).notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  operatingHours: text("operating_hours"),
  isVerified: boolean("is_verified").default(false),
  rating: decimal("rating", { precision: 2, scale: 1 }),
  kycDocument: text("kyc_document"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tyreDeals = pgTable("tyre_deals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  providerId: varchar("provider_id").references(() => serviceProviders.id),
  brand: text("brand").notNull(),
  model: text("model").notNull(),
  size: text("size").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  availability: boolean("availability").default(true),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertServiceProviderSchema = createInsertSchema(serviceProviders).omit({
  id: true,
  createdAt: true,
  isVerified: true,
  rating: true,
});

export const insertTyreDealSchema = createInsertSchema(tyreDeals).omit({
  id: true,
});

export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  providerId: varchar("provider_id").references(() => serviceProviders.id).notNull(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  service: text("service").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const rsaRequests = pgTable("rsa_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userPhone: text("user_phone").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 7 }).notNull(),
  longitude: decimal("longitude", { precision: 10, scale: 7 }).notNull(),
  location: text("location").notNull(),
  issue: text("issue").notNull(),
  status: text("status").notNull(),
  providerId: varchar("provider_id").references(() => serviceProviders.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const partnerOnboarding = pgTable("partner_onboarding", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phone: text("phone").notNull(),
  status: text("status").notNull(),
  businessData: text("business_data"),
  kycDocuments: text("kyc_documents").array(),
  rejectionReason: text("rejection_reason"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
});

export const insertRSARequestSchema = createInsertSchema(rsaRequests).omit({
  id: true,
  createdAt: true,
});

export const insertPartnerOnboardingSchema = createInsertSchema(partnerOnboarding).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateServiceProviderSchema = z.object({
  businessName: z.string().optional(),
  phone: z.string().optional(),
  services: z.array(z.string()).optional(),
  operatingHours: z.string().optional(),
  isVerified: z.boolean().optional(),
  rating: z.string().optional(),
});

export const updateOrderStatusSchema = z.object({
  status: z.string().min(1),
});

export const updateRSARequestSchema = z.object({
  status: z.string().optional(),
  providerId: z.string().optional(),
});

export const updatePartnerOnboardingSchema = z.object({
  status: z.string().optional(),
  businessData: z.string().optional(),
  kycDocuments: z.array(z.string()).optional(),
  rejectionReason: z.string().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type ServiceProvider = typeof serviceProviders.$inferSelect;
export type InsertServiceProvider = z.infer<typeof insertServiceProviderSchema>;
export type TyreDeal = typeof tyreDeals.$inferSelect;
export type InsertTyreDeal = z.infer<typeof insertTyreDealSchema>;
export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type RSARequest = typeof rsaRequests.$inferSelect;
export type InsertRSARequest = z.infer<typeof insertRSARequestSchema>;
export type PartnerOnboarding = typeof partnerOnboarding.$inferSelect;
export type InsertPartnerOnboarding = z.infer<typeof insertPartnerOnboardingSchema>;
export type UpdateServiceProvider = z.infer<typeof updateServiceProviderSchema>;
export type UpdateOrderStatus = z.infer<typeof updateOrderStatusSchema>;
export type UpdateRSARequest = z.infer<typeof updateRSARequestSchema>;
export type UpdatePartnerOnboarding = z.infer<typeof updatePartnerOnboardingSchema>;
